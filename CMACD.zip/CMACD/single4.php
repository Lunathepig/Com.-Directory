<?php include('headtag.php'); ?>

<body class="body-wrapper">
    <?php include('header.php'); ?>
    
    <!--===================================
=            Trend Section            =
====================================-->
<section class="section bg-gray">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<!-- Left sidebar -->
			<div class="col-md-8">
				<div class="product-details">
					<h1 class="product-title">Marina grants Lite Ferries missionary routes to serve Southern Leyte-Surigao rout</h1>
					<div class="product-meta">
						<ul class="list-inline">
							<li class="list-inline-item"><i class="fa fa-user-o"></i> By <a href="">Marites blog Spot!!</a></li>
							<li class="list-inline-item"><i class="fa fa-folder-open-o"></i> Category<a href="">News</a></li>
							<li class="list-inline-item"><i class="fa fa-location-arrow"></i> Location<a href="">San Juan(Cabalian) So. Leyte</a></li>
						</ul>
					</div>

					<!-- product slider -->
					<div class="product-slider">
						<div class="product-slider-item my-4" data-image="images/products/san.jpg">
							<img class="img-fluid w-100" src="images/trendtopic/lite.jpg" alt="product-img">
						</div>
						<div class="product-slider-item my-4" data-image="images/products/products-2.jpg">
							<img class="d-block img-fluid w-100" src="images/products/products-2.jpg" alt="Second slide">
						</div>
						<div class="product-slider-item my-4" data-image="images/products/products-3.jpg">
							<img class="d-block img-fluid w-100" src="images/products/products-3.jpg" alt="Third slide">
						</div>
						<div class="product-slider-item my-4" data-image="images/products/products-1.jpg">
							<img class="d-block img-fluid w-100" src="images/products/products-1.jpg" alt="Third slide">
						</div>
						<div class="product-slider-item my-4" data-image="images/products/products-2.jpg">
							<img class="d-block img-fluid w-100" src="images/products/products-2.jpg" alt="Third slide">
						</div>
					</div>
					<!-- product slider -->

					<div class="content mt-5 pt-5">
						<ul class="nav nav-pills  justify-content-center" id="pills-tab" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home"
								 aria-selected="true">Details</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile"
								 aria-selected="false">Specifications</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact"
								 aria-selected="false">Reviews</a>
							</li>
						</ul>
						<div class="tab-content" id="pills-tabContent">
							<div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
								<h3 class="tab-title">Description</h3>
								<p>LITE Shipping Corp.,which operates Lite Ferries, will deploy a daily ferry service connecting San Juan (Cabalian),Southern Leyte to Lipata, Surigao City on the request of the Maritime Industry Authority (Marina).
		    		The launching of the route was postponed due to the onslaught of Typhoon Odette (Rai) on Dec. 16, 2021, which left the ports of Lipata and San Juan badly damaged.
		    	Lite Ferry 11 is a roro passenger vessel that can cars.It can accommodate 550 passengers in a lying accommodation with bed bunks. 
		    	It will have two round trips daily, departing Lipata at 12noon and 12 midnight and leaving Liloan at 7 a.m. and 7 p.m. Travel time is only three and a half hours.</p>

								<iframe width="100%" height="400" src="https://www.youtube.com/embed/LUH7njvhydE?rel=0&amp;controls=0&amp;showinfo=0"
								 frameborder="0" allowfullscreen></iframe>
								<p></p>
								<p>LITE Shipping Corp.,which operates Lite Ferries, will deploy a daily ferry service connecting San Juan (Cabalian),Southern Leyte to Lipata, Surigao City on the request of the Maritime Industry Authority (Marina).
		    		The launching of the route was postponed due to the onslaught of Typhoon Odette (Rai) on Dec. 16, 2021, which left the ports of Lipata and San Juan badly damaged.
		    	Lite Ferry 11 is a roro passenger vessel that can cars.It can accommodate 550 passengers in a lying accommodation with bed bunks. 
		    	It will have two round trips daily, departing Lipata at 12noon and 12 midnight and leaving Liloan at 7 a.m. and 7 p.m. Travel time is only three and a half hours.</p>

							</div>
							<div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
								<h3 class="tab-title">Marina grants Lite Ferries missionary routes to serve Southern Leyte-Surigao rout</h3>
								<table class="table table-bordered product-table">
									<tbody>
										<tr>
											<td>Address</td>
											<td>San Juan Southern leyte (Cabalian)</td>
										</tr>
										<tr>
											<td>Event date</td>
											<td>11th February 2022</td>
										</tr>
										<tr>
											<td>State</td>
											<td>Dhaka</td>
										</tr>
										<tr>
											<td>Brand</td>
											<td>Apple</td>
										</tr>
										<tr>
											<td>Condition</td>
											<td>Used</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
								<h3 class="tab-title">Review</h3>
								<div class="product-review">
									<div class="media">
										<!-- Avater -->
										<img src="images/user/kat.jpg" alt="avater">
										<div class="media-body">
											<!-- Ratings -->
											<div class="ratings">
												<ul class="list-inline">
													<li class="list-inline-item">
														<i class="fa fa-star"></i>
													</li>
													<li class="list-inline-item">
														<i class="fa fa-star"></i>
													</li>
													<li class="list-inline-item">
														<i class="fa fa-star"></i>
													</li>
													<li class="list-inline-item">
														<i class="fa fa-star"></i>
													</li>
													<li class="list-inline-item">
														<i class="fa fa-star"></i>
													</li>
												</ul>
											</div>
											<div class="name">
												<h5>Katrina Vicencio</h5>
											</div>
											<div class="date">
												<p>july 30,, 2020</p>
											</div>
											<div class="review-comment">
												<p>
													we hope so...
												</p>
											</div>
										</div>
									</div>
									<div class="review-submission">
										<h3 class="tab-title">Submit your review</h3>
										<!-- Rate -->
										<div class="rate">
											<div class="starrr"></div>
										</div>
										<div class="review-submit">
											<form action="#" class="row">
												<div class="col-lg-6">
													<input type="text" name="name" id="name" class="form-control" placeholder="Name">
												</div>
												<div class="col-lg-6">
													<input type="email" name="email" id="email" class="form-control" placeholder="Email">
												</div>
												<div class="col-12">
													<textarea name="review" id="review" rows="10" class="form-control" placeholder="Message"></textarea>
												</div>
												<div class="col-12">
													<button type="submit" class="btn btn-main">Sumbit</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="sidebar">
					<!-- User Profile widget -->
					<div class="widget user text-center">
						<img class="rounded-circle img-fluid mb-5 px-5" src="images/user/banner.jpeg" alt="">
						<h4><a href="">Marites blog Spot!</a></h4>
						<p class="member-time">Member Since June, 2020</p>
						<a href="">See all ads</a>
						<ul class="list-inline mt-20">
							<li class="list-inline-item"><a href="" class="btn btn-contact d-inline-block  btn-primary px-lg-5 my-1 px-md-3">Contact</a></li>
							<li class="list-inline-item"><a href="" class="btn btn-offer d-inline-block btn-primary ml-n1 my-1 px-lg-4 px-md-3">Make an
									offer</a></li>
						</ul>
					</div>
					<!-- Map Widget -->
					<div class="widget map">
						<div class="map">
							<div id="map_canvas" data-latitude="51.507351" data-longitude="-0.127758"></div>
						</div>
					</div>
					<!-- Rate Widget -->
					<div class="widget rate">
						<!-- Heading -->
						<h5 class="widget-header text-center">What would you rate
							<br>
							this topic</h5>
						<!-- Rate -->
						<div class="starrr"></div>
					</div>
					
					<!-- Coupon Widget -->
					<div class="widget coupon text-center">
						<!-- Coupon description -->
						<p>Have a great topics to post ? Share it with
							your fellow users.
						</p>
						<!-- Submii button -->
						<a href="" class="btn btn-transparent-white">Submit Listing</a>
					</div>

				</div>
			</div>

		</div>
	</div>
	<!-- Container End -->
</section>
<!-- Footer Bottom -->
<?php include('footer.php'); ?>
  <!-- Container End -->
  <!-- To Top -->
  <div class="top-to">
    <a id="top" class="" href="#"><i class="fa fa-angle-up"></i></a>
  </div>


<!-- JAVASCRIPTS -->
<?php include('javascript.php'); ?>
</body>

</html>