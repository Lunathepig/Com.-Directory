<?php

$conn = new mysqli('localhost', 'root', '', 'cmacd_sanjuan_data');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>